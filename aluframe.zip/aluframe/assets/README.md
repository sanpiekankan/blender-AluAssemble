# AluFrame assets

此目录用于存放型材/配件等数据资源（JSON），暂为空。

后续迭代将添加：
- profiles.json：国标/欧标常用型材参数
- fittings.json：基础配件参数
- icons/：工具/面板图标资源